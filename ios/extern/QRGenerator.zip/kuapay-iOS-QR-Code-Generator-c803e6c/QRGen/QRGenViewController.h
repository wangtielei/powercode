//
//  QRGenViewController.h
//  QRGen
//
//  Created by Patrick Hogan on 7/26/11.
//  Copyright 2011 Kuapay LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QRGenViewController : UIViewController
{
}
@property (nonatomic,retain) IBOutlet UIImageView *imageView;

@end
