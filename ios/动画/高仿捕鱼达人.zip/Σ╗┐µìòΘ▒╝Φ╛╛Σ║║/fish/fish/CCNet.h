//
//  CCNet.h
//  fish
//
//  Created by  on 12-4-12.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface CCNet : CCSprite
{
    bool isCatching;
}
@property (nonatomic,assign) bool isCatching;
@end