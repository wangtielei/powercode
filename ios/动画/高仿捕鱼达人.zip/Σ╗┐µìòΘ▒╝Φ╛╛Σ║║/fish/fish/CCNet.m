//
//  CCNet.m
//  fish
//
//  Created by  on 12-4-12.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "CCNet.h"

@implementation CCNet
@synthesize isCatching;



@end