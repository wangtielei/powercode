//
//  ViewController.h
//  FireBall
//
//  Created by Weever on 12-6-20.
//  Copyright (c) 2012年 Linkcity. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController {
    
    CGPoint pos;
	UIImageView* fireBall;
}

@end
